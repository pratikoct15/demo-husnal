(function($) {
  "use strict"; // Start of use strict
})(jQuery); // End of use strict
